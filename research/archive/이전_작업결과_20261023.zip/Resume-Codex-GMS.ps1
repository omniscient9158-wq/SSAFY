$ErrorActionPreference = 'Stop'

# Resume the existing conversation with an explicit GMS provider.
# Close this conversation in the desktop app before running this script.
# This script does not contain or print credentials or send a model prompt.
$codexExe = 'C:\Users\SSAFY\AppData\Local\OpenAI\Codex\bin\6257d9e8f63c0f2b\codex.exe'
$projectDir = 'C:\Users\SSAFY\Desktop\Practice\ai-pjt-2'
$conversationId = '01a16167-0119-7752-b36c-51a0cd4ea899'

if (-not (Test-Path -LiteralPath $codexExe)) {
    throw 'Codex executable has moved. Update codexExe to the installed Codex CLI path.'
}

Write-Host 'Opening the existing conversation with provider=gms, model=gpt-5.4.'
Write-Host 'Before sending a message, run /status and confirm SSAFY GMS.'
Write-Host 'If the conversation is locked, close it in the desktop app and retry.'
& $codexExe --profile gms --strict-config -c 'model_provider="gms"' -m gpt-5.4 resume $conversationId --no-daemon -C $projectDir
exit $LASTEXITCODE
