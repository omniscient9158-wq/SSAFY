"""Isolated browser checks; does not change the real .env or indexes."""
import os
from pathlib import Path
import runpy
import sys

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / "src"))
import config

mode = sys.argv[1] if len(sys.argv) > 1 else "missing-key"
if mode == "missing-key":
    os.environ.pop("GMS_KEY", None)
elif mode == "empty-index":
    config.INDEX_DIR = root / "outputs" / "empty_index_for_ui_check"
else:
    raise ValueError("Unknown isolated check mode")
runpy.run_path(str(root / "app.py"), run_name="__main__")
