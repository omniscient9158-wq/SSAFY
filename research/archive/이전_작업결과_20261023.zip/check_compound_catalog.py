"""Offline behavioral checks for compound discovery and alias identity."""
import csv
import io
import json
import sys
import tempfile
from pathlib import Path

root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(root / "src"))
(root / "outputs" / "tmp").mkdir(exist_ok=True)
tempfile.tempdir = str(root / "outputs" / "tmp")

from compound_catalog import READY, PENDING, RECORD_ONLY, load_catalog, filter_catalog, catalog_csv
from streamlit.testing.v1 import AppTest

items = load_catalog()
assert len(items) == 7488
assert sum(x["문헌 근거"] == READY for x in items) == 6
assert sum(x["문헌 근거"] == PENDING for x in items) == 94
assert sum(x["문헌 근거"] == RECORD_ONLY for x in items) == 7388
for term in ("나이아신아마이드", "니아신아마이드", "니코틴아마이드", "niacinamide", "98-92-0", "DFPAKSUCGFBDDF-UHFFFAOYSA-N"):
    assert "A-659" in {x["AqSolDB ID"] for x in filter_catalog(items, term)}
# The catalog intentionally shows derivatives on substring queries; direct
# analysis must prefer the exact alias over the substituted derivative B-2554.
assert {"A-659", "B-2554"} <= {x["AqSolDB ID"] for x in filter_catalog(items, "nicotinamide")}
assert not filter_catalog(items, "niacinamide", READY)
assert not filter_catalog(items, "unregistered-xyz")
assert len(list(csv.DictReader(io.StringIO(catalog_csv(items).decode("utf-8-sig"))))) == 7488
app = AppTest.from_file(str(root / "app.py"), default_timeout=60).run()
assert not app.exception, app.exception
app.text_input(key="catalog-query").set_value("나이아신아마이드").run()
assert not app.exception, app.exception
assert app.selectbox(key="catalog-compound-id").value == "A-659"
next(button for button in app.button if button.label == "선택한 화합물 열기").click().run()
assert not app.exception, app.exception
assert app.session_state["compound-analysis"] == {"kind": "record", "compound_id": "A-659"}
assert any(x.value == "나이아신아마이드" for x in app.subheader)
app.text_input(key="compound-query").set_value("nicotinamide")
next(button for button in app.button if button.label == "분석하기").click().run()
assert not app.exception, app.exception
assert app.session_state["compound-analysis"]["compound_id"] == "A-659"
for query, expected_id in (("에탄올", "A-356"), ("글리세롤", "A-1896"), ("아세톤", "B-131")):
    app.text_input(key="compound-query").set_value(query)
    next(button for button in app.button if button.label == "분석하기").click().run()
    assert not app.exception, app.exception
    assert app.session_state["compound-analysis"]["compound_id"] == expected_id
app.text_input(key="catalog-query").set_value("").run()
app.selectbox(key="catalog-status").set_value(READY).run()
assert not app.exception, app.exception
assert len(app.dataframe[0].value) == 6
app.selectbox(key="catalog-status").set_value("전체").run()
page_widget = next(widget for widget in app.selectbox if widget.label.startswith("목록 페이지"))
page_widget.set_value(150).run()
assert not app.exception, app.exception
assert len(app.dataframe[0].value) == 38
result = {"train_catalog": len(items), "reviewed": 6, "review_pending": 94, "record_only": 7388,
          "niacinamide_id": "A-659", "alias_identity_source": "https://webbook.nist.gov/cgi/cbook.cgi?ID=C98920",
          "checks": ["Korean/English/CAS/InChIKey lookup", "CSV 7488 rows roundtrip", "catalog selection opens analysis",
                     "exact English alias beats derivative", "Wikidata Korean ethanol/glycerol/acetone lookup", "reviewed-only filter 6", "last page 38 rows"],
          "wiki_candidate_compounds": len(filter_catalog(items, document_only=True)), "api_calls": 0}
(root / "docs" / "evidence" / "compound_catalog_check.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(result, ensure_ascii=True))
